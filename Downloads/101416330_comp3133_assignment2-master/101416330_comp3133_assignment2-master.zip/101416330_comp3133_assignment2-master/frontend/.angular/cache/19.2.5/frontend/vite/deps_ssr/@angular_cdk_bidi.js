import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
} from "./chunk-ZDUMQYT4.js";
import "./chunk-67MVZYYZ.js";
import "./chunk-24GRDNIF.js";
import "./chunk-ZUJ64LXG.js";
import "./chunk-XCIYP5SE.js";
import "./chunk-OYTRG5F6.js";
import "./chunk-YHCV7DAQ.js";
export {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
};
